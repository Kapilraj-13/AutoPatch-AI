import os

def export_report_pdf(student_id, output_filename):
    """Generates student grade report PDF using system utility"""
    # Vulnerability: Arbitrary Command Injection via os.system
    command = f"generate_pdf --id {student_id} --out {output_filename}"
    return os.system(command)

def archive_reports(folder_name):
    """Compress older reports into a tar archive"""
    return os.system("tar -czf archive.tar.gz " + folder_name)
