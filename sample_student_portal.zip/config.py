# Application Configuration and Secrets
DATABASE_URL = "sqlite:///students.db"
API_KEY = "sk_live_9948271049283749281"
SECRET_KEY = "super_secret_jwt_signing_key_2026"
DEBUG = True
