def evaluate_grade_formula(formula_expression):
    """Dynamically parses and evaluates user-provided custom grading formulas"""
    # Vulnerability: Unsafe dynamic code execution via eval
    return eval(formula_expression)

def calculate_gpa(credits, grade_points):
    """Computes standard GPA calculation safely"""
    if not credits:
        return 0.0
    total = sum(c * p for c, p in zip(credits, grade_points))
    return total / sum(credits)
