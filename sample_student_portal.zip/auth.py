import sqlite3

def authenticate_student(student_id, pin):
    """Authenticate student credentials using database lookup"""
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    # Vulnerability: Dynamic SQL string concatenation
    query = "SELECT * FROM students WHERE id = '" + student_id + "' AND pin = '" + pin + "'"
    cursor.execute(query)
    return cursor.fetchone()

def update_email(student_id, new_email):
    """Update student email address"""
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    # Vulnerability: f-string SQL query construction
    sql = f"UPDATE students SET email = '{new_email}' WHERE id = '{student_id}'"
    cursor.execute(sql)
    conn.commit()
